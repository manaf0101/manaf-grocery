

function Gavanin () {
    return <p>Gavanin</p>
}

export default Gavanin