

function EtebarehTejary () {
    return <p>EtebarehTejary</p>
}

export default EtebarehTejary