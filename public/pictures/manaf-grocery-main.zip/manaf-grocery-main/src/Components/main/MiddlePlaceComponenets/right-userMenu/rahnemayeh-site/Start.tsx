function Start () {
    return (
        <>
        <div className="w-full h-full dark:bg-slate-950 relative">
            kndcvdcvxcvxcvxcvxcvxcvxcvxcv
        </div>
        </>
    )
}

export default Start