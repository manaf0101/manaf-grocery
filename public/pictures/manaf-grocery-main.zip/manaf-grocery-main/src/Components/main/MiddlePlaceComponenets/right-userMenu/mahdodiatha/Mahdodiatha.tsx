

function Mahdodiatha () {
    return <p>Mahdodiatha</p>
}

export default Mahdodiatha