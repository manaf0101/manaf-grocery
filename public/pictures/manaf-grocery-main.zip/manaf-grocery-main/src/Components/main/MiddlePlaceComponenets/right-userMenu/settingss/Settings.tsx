

function Settings () {
return <p>Settings</p>
}

export default Settings