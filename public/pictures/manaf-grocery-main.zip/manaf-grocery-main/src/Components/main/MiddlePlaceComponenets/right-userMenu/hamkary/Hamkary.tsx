

function Hamkary () {
    return <p>Hamkary</p>
}

export default Hamkary