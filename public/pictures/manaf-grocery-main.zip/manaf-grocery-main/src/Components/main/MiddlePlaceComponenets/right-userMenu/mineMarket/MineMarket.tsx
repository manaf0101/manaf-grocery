
function MineMarket () {
    return <p>market man</p>
}

export default MineMarket